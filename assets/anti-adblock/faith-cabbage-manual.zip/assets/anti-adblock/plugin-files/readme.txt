=== Ad Blocking Detector - Block List Countermeasure ===
Contributors: jtmorris
Donate link: http://adblockingdetector.jtmorris.net/
Tags: adblock, adblocker, ad blocker, adblock plus, detector, advertisement, ads, ad blocking
Requires at least: 3.9
Tested up to: 4.1
Stable tag: 2.2.8
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html